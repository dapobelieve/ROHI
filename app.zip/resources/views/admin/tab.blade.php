<div class="row">
                        <div class="col-xs-12 center" style="text-align: center;">                  
                            <ul class="quick-actions">
                                <li>
                                    <a href="#">
                                        <i class="icon-cal"></i>
                                        Manage Events
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-shopping-bag"></i>
                                        Manage Orders
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-database"></i>
                                        Manage DB
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-people"></i>
                                        Manage Users
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-lock"></i>
                                        Security
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-piechart"></i>
                                        Statistics
                                    </a>
                                </li>
                            </ul>
                        </div>  
                    </div>