<?php $__env->startSection('title'); ?>
ROHI : <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>
    <section class="slider-section" style="background-repeat: no-repeat;background-image:url(/assets/images/slider/2.jpg);">
            <div class="container">
                <div class="slider">
                    <div class="text team-light">
                        <h2>Report Details </h2>
                        <p><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> <a href="<?php echo e(route('events')); ?>">Report</a> <i class="fa fa-angle-right" aria-hidden="true"></i>Details</p>
                    </div>
                </div>
            </div>
        </section>
        <!--End slider-section-->
        <!--.blog-seciton-->
        <section class="blog-seciton blog-pag">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <!-- Start single-item -->
                        <div class="blog-item clearfix">
                            <div class="img-holder">
                               <img src="/dikwa/<?php echo e($post->image1); ?>" alt="Images">
                            </div>
                            <br>
                            <h2><?php echo e($post->title); ?> </h2>
                            <p style="white-space: pre-line;font-size: 14px !important" class="text-justify">
                                <?php echo e($post->content); ?>

                            </p>
                            <br>
                            <br>
                            <div class="">
                               <img class="img-responsive" src="/dikwa/<?php echo e($post->graph); ?>" alt="Images">
                            </div>
                            <div class="tags">
                                
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-12">
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>