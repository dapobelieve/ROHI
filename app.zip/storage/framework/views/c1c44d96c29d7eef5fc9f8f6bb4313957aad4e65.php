<?php $__env->startSection('title'); ?>
ROHI : Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>
<section class="slider-section" style="min-height: 200px;background-image:url(/assets/images/slider/2.jpg);">
    <div class="container">
        <div class="slider">
            <div class="text team-light">
                <h2> <span>Situation Report</h2>
                <p><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> Situation Report</p>
            </div>
        </div>
    </div>
</section>

<section class="event-seciton event-page">
        <div class="container">
           <div class="row">
                <div class="col-md-9 col-sm-8 col-xs-12">
                    <div class="section-title text-center">
                        <h2><span>Recent Reports</span></h2>
                    </div>
                    <div class="row">
                        <div class="col-md-8 col-sm-6 col-xs-12">
                            <!-- Start single-item -->
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="">
                                <div style="padding-bottom: 20px; maring-bottom: 100px ">
                                    <a href="<?php echo e(route('report-details', ['id' => $report->id])); ?>">
                                        <img class="img-responsive" src="/dikwa/<?php echo e($report->image1); ?>" alt="Images">
                                    </a>                                    
                                </div>
                                <h4>
                                    <a href="<?php echo e(route('report-details', ['id' => $report->id])); ?>"><?php echo e(title_case($report->title)); ?><br> 
                                    </a>
                                </h4>
                            </div>
                            <br>
                            <br>
                            <br>
                            <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End single-item -->
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <!-- Start side-bar -->
                    <div class="side-bar">
                    </div>
                    <!-- Eind side-bar -->
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>