<?php $__env->startSection('admin-content'); ?>
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<strong>Errors:</strong>
				<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li> <?php echo e($error); ?> </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		<div class="widget-box">
	    <div class="widget-title">
	        <span class="icon"><i class="fa fa-signal"></i></span>
	        <h5>Posted Images</h5>
	        
	    </div>
	    <div class="widget-content">
	    <?php echo $__env->make('template.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	        <div class="row">
	            <div class="widget-content nopadding">
	                <table class="table table-bordered table-striped table-hover catArr">
	                    <thead>
	                        <tr>
	                            <th class="col-xs-3">Caption</th>
	                            <th class="col-xs-4">Image</th>
	                            <th class="col-xs-3">Date Posted</th>
	                            <th class="col-xs-2">Action</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <tr data-zid="">
	                            <td><?php echo e($post->caption); ?></td>
	                            <td>
	                            	<img style="width:40px" class="img-responsive" src="<?php echo e($post->img); ?>">
	                            </td>
	                            <td><?php echo e($post->created_at->diffForHumans()); ?></td>
	                            <td>
	                            <div class="btn-group">
										<button data-toggle="dropdown" class="btn btn-xs btn-danger dropdown-toggle">Options <span class="caret"></span></button>
										<ul class="dropdown-menu dropdown-danger">
											<li><form action="<?php echo e(route('gala.edit', $post->id)); ?>" method="GET">
				                            	<?php echo e(csrf_field()); ?>

				                            	<button class="btn btn-default btn-xs cdit">
				                            	<i class="fa fa-edit"></i> Edit</button> 
				                            </form></li>
											<li>
												<form action="<?php echo e(route('gala.destroy', $post->id)); ?>" method="POST">
													<?php echo e(method_field('DELETE')); ?>

						                            <?php echo e(csrf_field()); ?>

					                            	<button class="btn btn-default btn-xs cdel"><i class="fa fa-trash-o"></i> Delete</button>
					                            </form>
											</li>
											
										</ul>
									</div>
	                            </td>
	                        </tr>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </tbody>
	                </table>                            
	            </div>
	        </div>
	        <br>
	        <br>
	        <br>
	                 <a href="<?php echo e(route('gala.create')); ?>" class="btn btn-default btn-md" >+ Add</a>           
	    </div>
     </div>
     
     	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>