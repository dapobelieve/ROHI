<?php $__env->startSection('title'); ?>
ROHI : Events
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>

    <section class="slider-section" style="background-image:url(/assets/images/slider/2.jpg);">
        <div class="container">
            <div class="slider">
                <div class="text team-light">
                    <h2> <span>All</span> Events </h2>
                    <p><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> Events</p>
                </div>
            </div>
        </div>
    </section>
    <!--End slider-section-->
     <!--.event-seciton-->
    <section class="event-seciton event-page">
        <div class="container">
           <div class="row">
                <div class="col-md-9 col-sm-8 col-xs-12">
                    <div class="section-title text-center">
                        <h2><span>Events</span></h2>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-8 col-sm-6 col-xs-12">
                            <!-- Start single-item -->
                            <div class="event-item">
                                <div class="img-holder">
                                   <figure><a href="<?php echo e(route('event.post', ['pid' => $post->slug])); ?>"><img src="<?php echo e($post->singleImage()); ?>" alt="Images"></a></figure>
                                    <div class="text">
                                        <h4>
                <a href="<?php echo e(route('event.post', ['pid' => $post->slug])); ?>"><?php echo e($post->created_at->format('jS F Y ')); ?><br> <span><?php echo e($post->title); ?></span></a></h4>
                                    </div>
                                </div>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                   
                </div>
                <div class="col-md-3 col-sm-4 col-xs-12">
                    <!-- Start side-bar -->
                    <div class="side-bar">
                    </div>
                    <!-- Eind side-bar -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>