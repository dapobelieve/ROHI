<?php if(Session::has('info')): ?>
	<div class="alert alert-info alert-dismissible" role='alert'>
		<?php echo e(Session::get('info')); ?>

	</div>
<?php endif; ?> 