<?php $__env->startSection('title'); ?>
ROHI : Contact Us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>

 <section class="slider-section" style="background-image:url(/assets/images/slider/2.jpg);">
            <div class="container">
                <div class="slider">
                    <div class="text">
                        <p><a href="<?php echo e(route('home')); ?>">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</p>
                    </div>
                </div>
            </div>
        </section>

<section class="contact-section contact-page">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Contact Us</h2>
                    <p>We would love to hear your comments, advice or enquires.Contact us on any of the following channels.  </p>
                </div>
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12">
                        <div class="contact-us">
                            <div class="contaat-item">
                                <div class="icon" style="margin-bottom:2px">
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                </div>
                                <div class="text">
                                    <h4>Address:</h4>
                                    
                                    <p>Suite 4 Red Roof Upstairs Opp. M.M Ali Oil Station Bama Road,<br> Maiduguri, Borno State.</p>
                                    <p>Nurses Welfare House INEC Road Demsawo Jimeta Yola,Adamawa State.</p>
                                    <p>Adjacent new Era Nursery and Primary School Jalingo Taraba State</p>
                                </div>
                            </div>
                            <div class="contaat-item con-pd">
                                <div class="icon" style="margin-bottom:2px">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <div class="text">
                                    <h4>Email Address:</h4>
                                    <p>roselinepeters@restorationofhopeinitiative.org</p>
                                    <p>benjaminjohn@restorationofhopeinitiative.org</p>
                                    <p>alamazira@restorationofhopeinitiative.org</p>
                                    <p>hauwamamza@restorationofhopeinitiative.org</p>
                                    <p>maimunaali@restorationofhopeinitiative.org</p>
                                    <p>richardpeters@restorationofhopeinitiative.org</p>
                                    <p>salwanajonah@restorationofhopeinitiative.org</p>
                                    <p>victoranekunu@restorationofhopeinitiative.org</p>
                                    <p>joshuapeter@restorationofhopeinitiative.org</p>
                                    <p>desmondpeter@restrationofhopeinitiative.org</p>
                                    <p>info@restrationofhopeinitiative.org</p>
                                    <p>recruitment@restrationofhopeinitiative.org</p>
                                </div>
                            </div>
                            <div class="contaat-item con-pd">
                                <div class="icon">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <div class="text">
                                    <h4>Phone</h4>
                                    <p>07065784570</p>
                                    <p>08058917183</p>
                                </div>
                            </div>
                            
                        </div>
                                     
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>