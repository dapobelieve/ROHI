<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dapo extends Model
{
    //
}
