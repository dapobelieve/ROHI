@extends('layout')


@section('pageContent')
 @include('includes.slider')
        <!-- /banner -->
	<!-- ====================== /Banner =================== -->
        <!--.mission-seciton-->
        @include('includes.mission')
        <!--/mission-seciton-->
        <!--.welcome-seciton-->
        <section class="welcome-seciton page-3">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Recent <span>Events</span></h2>
                </div>
                <div class="row">
                @foreach($eventy as $evento)
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <!-- Start single-item -->
                        <div class="welcome-item ">
                            <div class="img-holder">
                               <figure><a href="{{  route('event.post', ['pid' => $evento->slug]) }}"><img src="/assets/images/blog/r1.jpg" alt="Images"></a></figure>
                                <!-- Start overlay -->
                                <div class="overlay">
                                    <h4><a href="single-causes.html"><span>{{$evento->title}}</span></a></h4>
                                </div>
                                <!-- End overlay -->
                            </div>
                            <div class="text">
                                <p>{{ $evento->getSumry($evento->body, 20)}}...</p>
                                <a href="{{  route('event.post', ['pid' => $evento->slug]) }}">Read More</a>
                            </div>
                        </div>
                        <!-- End single-item -->
                    </div>
                @endforeach
                </div>
            </div>
        </section>
        <!--/wellcome-seciton-->
        <!--.event-seciton-->
        {{-- <section class="event-seciton">
            <div class="container">
                <div class="section-title">
                    <h2>upcoming <span>event</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor<br> 
                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim.</p>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <!-- Start single-item -->
                                <div class="event-item">
                                    <div class="img-holder">
                                       <figure><a href="single-event.html"><img src="/assets/images/blog/5.jpg" alt="Images"></a></figure>
                                        <div class="text">
                                            <h4><a href="single-event.html">October 5, 2017 <span>giving food</span></a></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End single-item -->
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <!-- Start single-item -->
                                <div class="event-item">
                                    <div class="img-holder">
                                       <figure><a href="single-event.html"><img src="/assets/images/blog/6.jpg" alt="Images"></a></figure>
                                        <div class="text">
                                            <h4><a href="single-event.html">October 5, 2017 <span>giving food</span></a></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End single-item -->
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <!-- Start single-item -->
                                <div class="event-item">
                                    <div class="img-holder">
                                       <figure><a href="single-event.html"><img src="/assets/images/blog/7.jpg" alt="Images"></a></figure>
                                        <div class="text">
                                            <h4><a href="single-event.html">October 5, 2017 <span>giving food</span></a></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End single-item -->
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <!-- Start single-item -->
                                <div class="event-item">
                                    <div class="img-holder">
                                       <figure><a href="single-event.html"><img src="/assets/images/blog/8.jpg" alt="Images"></a></figure>
                                        <div class="text">
                                            <h4><a href="single-event.html">October 5, 2017 <span>giving food</span></a></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End single-item -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <!-- Start single-item -->
                        <div class="event-right">
                            <div class="text">
                               <div class="date">
                                   <h4>19<span class="sep">th sep,</span> <span> 2017</span></h4>
                               </div>
                                <h2>help children: build a School for education</h2>
                                <h4>Join Our Event: <span>Donate</span></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore 
                                magna aliqua. Ut enim ad minim veniam, quis nostrud 
                                exercitation ullamco laboris nisi ut aliquip ex ea 
                                Lorem ipsum dolor sit amet, consectetur.</p>
                                <a href="single-event.html">View All Events</a>
                            </div>
                        </div>
                        <!-- End single-item -->
                    </div>
                </div>
            </div>
        </section> --}}
        <!--/event-seciton-->
        
        <!--.blog-seciton-->
       
        <!--/blog-seciton-->
        <!--Start volunteer-section -->
        <section class="volunteer-section" style="background-image:url(/assets/images/blog/xfiles/bg6.jpg);">
            <div class="container">
                <div class="volunteer-item">
                    <h2>WE HELP many people</h2>
                    <!-- <h4>want to become a <span> volunteer!</span></h4>
                    <p>Duis sed odio sit amet nibh vulpuate cursus a sit amet mauris. Morbi accumsan ipsuy veli<br>nec telus aodio tincidunt auctor Class aptent taciti sociosqu adlitora.</p>
                    <a href="#" class="btn-3">Apply now</a> -->
                </div> 
            </div>
        </section>
        <!--End volunteer-section -->
@stop