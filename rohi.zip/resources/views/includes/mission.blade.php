<section class="mission-seciton">
            <div class="container">
                <div class="section-title text-center">
                    <h2>our <span>mission</span></h2>
                    <p>"to expand access to quality, protective and relevant non-formal education and alternative <br>education opportunities to internally displaced school children"</p>
                </div>
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <!-- Start single-item -->
                        <div class="mission-item">
                            <i class="flaticon-medical"></i>
                            <h4><a href="#">give donation</a></h4>
                            <p>Pellentesque eu malesuada nisi as<br>
                                et condimen tum lorem ipsem vitae<br>
                                arcu eget lobortis cursus.</p>
                        </div>
                        <!-- End single-item -->
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <!-- Start single-item -->
                        <div class="mission-item">
                            <i class="flaticon-heart-3"></i>
                            <h4><a href="#">become volunteer</a></h4>
                            <p>Pellentesque eu malesuada nisi as<br>
                                et condimen tum lorem ipsem vitae<br>
                                arcu eget lobortis cursus.</p>
                        </div>
                        <!-- End single-item -->
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <!-- Start single-item -->
                        <div class="mission-item">
                            <i class="flaticon-heart"></i>
                            <h4><a href="#">fund raising</a></h4>
                            <p>Pellentesque eu malesuada nisi as<br>
                                et condimen tum lorem ipsem vitae<br>
                                arcu eget lobortis cursus.</p>
                        </div>
                        <!-- End single-item -->
                    </div>
                </div>
            </div>
        </section>