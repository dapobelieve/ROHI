<section class="main-slider">
                <div class="tp-banner-container">
                    <div class="tp-banner" >
                        <ul>
                            {{--  --}}
                            <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="/assets/images/slider/1.jpg"  data-saveperformance="off"  data-title="Awsome Service">
                            <img src="/assets/images/slider/1.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                            <div class="tp-caption lfl tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="-100"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="grey-title"><h3 style="color:white">Welcome to Restoration of Hope Initiative (ROHI)</h3></div></div>
                            <div class="tp-caption lfl tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="-40"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="grey-title"><h2>Help for the <span>poor</span> people</h2></div></div>

                            <div class="tp-caption lfr tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="50"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200" 
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="grey-title"><p>ROHI is an organization that has done a community mapping to intervene in communities<br>
                                that has a high number of internally displaced persons (IDPs) mostly girls and boys within school age of 6 – 17
years.<p></div></div>
                            <div class="tp-caption lfl tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="100"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="grey-title"><a href="{{route('about')}}" class="btn-3">Read More</a></div></div>
                            <div class="tp-caption lfr tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="400"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                              {{-- <div class="container">
                                <div class="slider-box  wow fadeInUp animated">
                                    <div class="slider-item bor">
                                        <img src="/assets/images/resources/1.png" alt="Images">
                                        <div class="text">
                                            <h4>Become a donator</h4>
                                            <p>Duis sed odio sit amet nibh vulpuo<br> ipsuy veli. </p>
                                            <a href="#">donate now <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                    <div class="slider-item bor">
                                        <img src="/assets/images/resources/2.png" alt="Images">
                                        <div class="text">
                                            <h4>Become a donator</h4>
                                            <p>Duis sed odio sit amet nibh vulpuo<br> ipsuy veli. </p>
                                            <a href="#">donate now <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                    <div class="slider-item">
                                        <img src="/assets/images/resources/3.png" alt="Images">
                                        <div class="text">
                                            <h4>Become a donator</h4>
                                            <p>Duis sed odio sit amet nibh vulpuo<br> ipsuy veli. </p>
                                            <a href="#">donate now <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                </div>  
                            </div> --}}
                            
                            </li>
                            <li data-transition="slidedown" data-slotamount="1" data-masterspeed="1000" data-thumb="/assets/images/slider/3.jpg"  data-saveperformance="off"  data-title="Professional Mechanics">
                            <img src="/assets/images/slider/3.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 

                            <div class="tp-caption lfb tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="-40"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="white-title"><h2><span>Impacting lives</span> is our mission</h2></div></div>
                            <div class="tp-caption lfr tp-resizeme"
                            data-x="center" data-hoffset="0"
                            data-y="center" data-voffset="50"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"
                            style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="grey-title"><p>Pellentesque eu malesuada nisi. Phasellus eget ornare arcu, et condimen tum lorem ipsem<br>vitae posuere nisi, at venenatis velit. Morbi lacinia lac us accumsan<p></div></div>
                            </li>
                        </ul>
                        {{-- <div class="tp-bannertimer"></div> --}}
 
                    </div>
                </div>
		</section> 