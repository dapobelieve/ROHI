<div id="sidebar">
    <ul>
        <li class="active"><a href="<?php echo e(route('hadmin')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li>
            <a href="<?php echo e(route('posts.index')); ?>"><i class="fa fa-signal"></i> <span>Events</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('gala.index')); ?>"><i class="fa fa-cogs"></i> <span>Gallery</span></a>
        </li>
        <li>
                        <a href="<?php echo e(route('auth')); ?>"><i class="fa exit"></i> <span>Logout</span></a>
        </li>
        
    </ul>
</div>