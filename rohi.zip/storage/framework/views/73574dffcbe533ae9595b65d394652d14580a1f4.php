<div class="container">
                     <div class="logo pull-left">
                        <a href="<?php echo e(route('home')); ?>"><img src="/assets/images/logo.png" alt=""></a>
                     </div>
                     <nav class="main-menu pull-right">
                            <div class="navbar-header">     
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse clearfix">
    <ul class="navigation clearfix">
        <li class="<?php echo e(Request::is( '/' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="<?php echo e(Request::is( 'events' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('events')); ?>">Events</a></li>
        <li class="<?php echo e(Request::is( 'gallery' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
        <li class="<?php echo e(Request::is( 'about' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('about')); ?>">About Us</a></li>
        <li class=""><a href="contact.html">Contact</a></li>
    </ul>
                                
                                <ul class="mobile-menu clearfix">
        <li class="<?php echo e(Request::is( '/' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="<?php echo e(Request::is( 'events' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('events')); ?>">Events</a></li>
        <li class="<?php echo e(Request::is( 'gallery' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
        <li class="<?php echo e(Request::is( 'about' ) ? ' current' : ''); ?>"><a href="<?php echo e(route('about')); ?>">About Us</a></li>
        <li class=""><a href="contact.html">Contact</a></li>
                                </ul>
                                
                            </div>
                     </nav>
                </div>