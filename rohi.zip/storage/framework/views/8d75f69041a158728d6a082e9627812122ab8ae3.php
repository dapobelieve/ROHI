 <nav class="omg_component footer-8" style="position: relative; left: 0px; top: 0px;">
    <div class="bg-color bg-black" style="background-color: rgb(0, 0, 0);">
      <div class="container-fluid">
        <div class="row v-align-flex">
          <div class="col-md-2 visible-sm visible-xs">
            <img alt="image" src="/afro/img/user_uploads/logo.png" class="img_responsive center-block">
          </div>
          <div class="col-md-4 text-center">
            <div class="row">
            <div class="col-md-4  bottom">
              <a href="<?php echo e(route('home')); ?>" class="title_small">Home</a>
            </div>
            <div class="col-md-4  bottom">
            <a href="<?php echo e(route('fela')); ?>" class="title_small">The Afrobeat Creator</a>
            </div>
            <div class="col-md-4  bottom">
            <a href="<?php echo e(route('live')); ?>" class="title_small">Watch Live</a>
            </div>
            </div>
          </div>
          <div class="col-md-2 hidden-sm hidden-xs  bottom">
            <img alt="image" src="/afro/img/user_uploads/logo.png" class="wow animated img_responsive center-block animated lightSpeedIn" style="">
          </div>
          <div class="col-md-4 text-center">
            <div class="row">
              <div class="col-md-4  bottom"><a href="<?php echo e(route('about')); ?>" class="title_small">About Afrobeat Party</a></div>
              <div class="col-md-4  bottom"><a href="<?php echo e(route('blog')); ?>" class="title_small">Blog</a></div>
              <div class="col-md-4  bottom"><a href="<?php echo e(route('gallery')); ?>" class="title_small">Gallery</a></div>
              <?php if(Auth::check()): ?>
              <div class="col-md-4  bottom"><a href="<?php echo e(route('auth')); ?>" class="title_small">Logout</a></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
       
      </div>
    </div>
</nav>