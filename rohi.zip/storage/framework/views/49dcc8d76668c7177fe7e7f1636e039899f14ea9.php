<?php $__env->startSection('admin-content'); ?>
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<strong>Errors:</strong>
				<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li> <?php echo e($error); ?> </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		<div class="widget-box">
	    <div class="widget-title">
	        <span class="icon"><i class="fa fa-signal"></i></span>
	        <h5>Update Post</h5>
	        
	    </div>
	    <div class="widget-content">
	    <?php echo $__env->make('template.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	        <div class="row">
	            <div class="widget-content nopadding">
	                <form method="post" action="<?php echo e(route('gala.update', $post->id )); ?>" enctype="multipart/form-data" class="form-horizontal"> 
	                	<?php echo e(method_field('PUT')); ?>


					  <div class="form-group">
						<label class="col-sm-3 col-md-3 col-lg-2 control-label">Post Title:</label>
						<div class="col-sm-9 col-md-9 col-lg-10">
							<input type="text" required name="postTitle" value="<?php echo e(Request::old('postTitle') ?: $post->caption); ?>" id="postTitle" class="form-control input-sm" />
						</div>
					</div>



					  <div class="form-group">
						<label class="col-sm-3 col-md-3 col-lg-2 control-label">Image</label>
						<div class="col-sm-9 col-md-9 col-lg-10">
							<input type="file" name="postImage" onchange="prevImg(event)" id="postImage" />
							<br>
							<img style="width:300px" id="output_image" src="<?php echo e($post->img); ?>">
						</div>
					</div>

					  <button type="submit" class="btn btn-default">Submit</button>

					  <?php echo e(csrf_field()); ?>

					</form>                           
	            </div>
	        </div>
	        <br>
	        <br>
	        <br>
	        
	    </div>
     </div>
<script type='text/javascript'>
	function prevImg(event) 
	{
	 var reader = new FileReader();
	 reader.onload = function()
	 {
	  var output = document.getElementById('output_image');
	  output.src = reader.result;
	 }
	 reader.readAsDataURL(event.target.files[0]);
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>