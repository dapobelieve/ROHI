<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="/css/app.css">
	<title></title>
</head>
<body>
	
	<div class="container">
		<?php echo $__env->make('adplate.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
	</div>

</body>
</html>