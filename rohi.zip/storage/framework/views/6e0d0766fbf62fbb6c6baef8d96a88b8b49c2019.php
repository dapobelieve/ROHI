<?php $__env->startSection('title'); ?>
ROHI : Gallery
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="/assets/css/lightbox.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>
<section class="slider-section" style="background-image:url(/assets/images/slider/2.jpg);">
            <div class="container">
                <div class="slider">
                    <div class="text team-light">
                        <h2>our <span> great </span> memories </h2>
                        <p><a href="index-2.html">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> Gallery</p>
                    </div>
                </div>
            </div>
        </section>
        <!--End slider-section-->
        <!--Start gallery-section-->
        <section class="gallery-section">
            <div class="container">
                <div class="sortable-masonry">
                                           
                    <div class="row items-container">
                        <div class="col-md-3 col-sm-6 col-xs-12 all food education">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/boy.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a data-lightbox="/assets/images/boy.jpg" href="/assets/images/boy.jpg"   data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4>A young boy with a scholastic kit</h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all education others">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/1gee.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a data-lightbox="/assets/images/1gee.jpg" href="/assets/images/1gee.jpg"  data-thumbnail="/assets/images/gallery/8.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all food others">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/kids.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a data-lightbox="/assets/images/kids.jpg" href="/assets/images/kids.jpg"  data-thumbnail="/assets/images/gallery/9.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all education">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/kido.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a class="html5lightbox" href="/assets/images/kido.jpg"  data-thumbnail="/assets/images/gallery/10.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all food others">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/bag.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a class="html5lightbox" href="/assets/images/bag.jpg"  data-thumbnail="/assets/images/gallery/11.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all others">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/gallery/12.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a class="html5lightbox" href="/assets/images/gallery/12.jpg"  data-thumbnail="/assets/images/gallery/12.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-12 all education">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="/assets/images/dembe.jpg" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a class="html5lightbox" href="/assets/images/dembe.jpg"  data-thumbnail="/assets/images/gallery/13.jpg" data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        
                    </div>
                </div>
               
            </div>
        </section>
        <!--End Gallery Section-->

        <!--.news-seciton-->
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripto'); ?>
<script src="/assets/js/lightbox.min.js"></script>

<script type="text/javascript">

    lightbox.option({
        'alwaysShowNavOnTouchDevices': true,
        'positionFromTop'   : 50,
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>