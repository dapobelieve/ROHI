<?php $__env->startSection('pageContent'); ?>
 <?php echo $__env->make('includes.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /banner -->
	<!-- ====================== /Banner =================== -->
        <!--.mission-seciton-->
        <?php echo $__env->make('includes.mission', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--/mission-seciton-->
        <!--.welcome-seciton-->
        <section class="welcome-seciton page-3">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Recent <span>Events</span></h2>
                </div>
                <div class="row">
                <?php $__currentLoopData = $eventy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <!-- Start single-item -->
                        <div class="welcome-item ">
                            <div class="img-holder">
                               <figure><a href="<?php echo e(route('event.post', ['pid' => $evento->slug])); ?>"><img src="/assets/images/blog/r1.jpg" alt="Images"></a></figure>
                                <!-- Start overlay -->
                                <div class="overlay">
                                    <h4><a href="single-causes.html"><span><?php echo e($evento->title); ?></span></a></h4>
                                </div>
                                <!-- End overlay -->
                            </div>
                            <div class="text">
                                <p><?php echo e($evento->getSumry($evento->body, 20)); ?>...</p>
                                <a href="<?php echo e(route('event.post', ['pid' => $evento->slug])); ?>">Read More</a>
                            </div>
                        </div>
                        <!-- End single-item -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!--/wellcome-seciton-->
        <!--.event-seciton-->
        
        <!--/event-seciton-->
        
        <!--.blog-seciton-->
       
        <!--/blog-seciton-->
        <!--Start volunteer-section -->
        <section class="volunteer-section" style="background-image:url(/assets/images/blog/xfiles/bg6.jpg);">
            <div class="container">
                <div class="volunteer-item">
                    <h2>WE HELP many people</h2>
                    <!-- <h4>want to become a <span> volunteer!</span></h4>
                    <p>Duis sed odio sit amet nibh vulpuate cursus a sit amet mauris. Morbi accumsan ipsuy veli<br>nec telus aodio tincidunt auctor Class aptent taciti sociosqu adlitora.</p>
                    <a href="#" class="btn-3">Apply now</a> -->
                </div> 
            </div>
        </section>
        <!--End volunteer-section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>