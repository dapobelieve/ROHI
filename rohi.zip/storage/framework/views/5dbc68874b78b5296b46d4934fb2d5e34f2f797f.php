<?php $__env->startSection('title'); ?>
ROHI : Gallery
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="/assets/css/lightbox.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>
<section class="slider-section" style="background-image:url(/assets/images/slider/2.jpg);">
            <div class="container">
                <div class="slider">
                    <div class="text team-light">
                        <h2>our <span> great </span> memories </h2>
                        <p><a href="index-2.html">Home</a> <i class="fa fa-angle-right" aria-hidden="true"></i> Gallery</p>
                    </div>
                </div>
            </div>
        </section>
        <!--End slider-section-->
        <!--Start gallery-section-->
        <section class="gallery-section">
            <div class="container">
                <div class="sortable-masonry">
                                           
                    <div class="row items-container">
                    <?php if(!$galas->count()): ?>
                    <p>No Images in the gallery yet..</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $galas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6 col-xs-12 all food education">
                            <!-- Start single-item -->
                            <div class="gallery-item">
                                <div class="img-holder">
                                   <figure><img src="<?php echo e($gala->img); ?>" alt="Images"></figure>
                                    <!-- Start overlay -->
                                    <div class="overlay">
                                      <a data-lightbox="<?php echo e($gala->img); ?>" href="<?php echo e($gala->img); ?>"   data-group="set1" data-width="800" data-height="600">
                                            <i class="fa fa-search" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                    <!-- End overlay -->   
                                </div>
                                    <h4><?php echo e($gala->caption); ?></h4>
                            </div>
                            <!-- End single-item -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>
                </div>
               
            </div>
        </section>
        <!--End Gallery Section-->

        <!--.news-seciton-->
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripto'); ?>
<script src="/assets/js/lightbox.min.js"></script>

<script type="text/javascript">

    lightbox.option({
        'alwaysShowNavOnTouchDevices': true,
        'positionFromTop'   : 50,
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>